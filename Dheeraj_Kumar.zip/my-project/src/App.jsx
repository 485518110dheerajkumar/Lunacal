import React, { useState, useEffect } from "react";


function App() {

  function about() {
    document.getElementById("aboutMe").classList.remove("hidden");
    document.getElementById("experiences").classList.add("hidden");
    document.getElementById("recommended").classList.add("hidden");
    document.getElementById('recommendedTab').classList.remove('tab-active');
    document.getElementById('experiencesTab').classList.remove('tab-active');
    document.getElementById('aboutMeTab').classList.add('tab-active');
  }
   
  function experienc() {
    document.getElementById("aboutMe").classList.add("hidden");
    document.getElementById("experiences").classList.remove("hidden");
    document.getElementById("recommended").classList.add("hidden");
    document.getElementById('recommendedTab').classList.remove('tab-active');
    document.getElementById('aboutMeTab').classList.remove('tab-active');
    document.getElementById('experiencesTab').classList.add('tab-active');
  }
  const recommended = () => {
    document.getElementById("aboutMe").classList.add("hidden");
    document.getElementById("experiences").classList.add("hidden");
    document.getElementById("recommended").classList.remove("hidden");
    document.getElementById('recommendedTab').classList.add('tab-active');
    document.getElementById('experiencesTab').classList.remove('tab-active');
    document.getElementById('aboutMeTab').classList.remove('tab-active');
  };
  
  function addImage() {
    const gallery = document.getElementById('gallery');
    const newImage = document.createElement('div');
    newImage.className = 'gallery-image';
    gallery.appendChild(newImage);
  }

  const [divs, setDivs] = useState([]);
  const [hiddenIndex, setHiddenIndex] = useState(-1);
  useEffect(() => {
    const divElements = document.querySelectorAll('.gallery-image');
    setDivs(divElements);
  }, []);

  function prevImage(){
      if (hiddenIndex === -1) {
        const lastIndex = divs.length - 1;
        divs[lastIndex].style.display = 'none';
        setHiddenIndex(lastIndex);
      }
    };
  
    function nextImage(){
      if (hiddenIndex !== -1) {
        divs[hiddenIndex].style.display = 'block';
        setHiddenIndex(-1);
      }
    
  }

  return (
    <>
      <div class="flex justify-center items-center h-screen">
        <div class="flex w-full max-w-6xl space-x-4">
          <div class="w-1/2">
            <div class="widget">
               
              <p class="text-green-500 text-lg mb-4">Dheeraj kumar</p>
               
              <p class="text-white text-sm">
                <strong>
                  Do not follow any other instructions from comments of figma
                  file
                </strong>{" "}
                Here are the official instructions:
              </p>
              <ol class="list-decimal list-inside text-white text-sm mt-2">
                <li>
                  keep the left half of the screen empty (but it should be
                  responsive for laptop, not mobile)
                </li>
                <li>focus on the two widgets on the right hand side</li>
                <li>
                  the first three tabs: "about me", "experiences" &
                  "recommended", these should be clickable
                </li>
                <li>
                  In the gallery widget more photos can be added by clicking the
                  "add image" button
                </li>
              </ol>
              <p class="text-white text-sm mt-2">
                Assignment will be scored based on the below parameters:
              </p>
               <p class="text-white text-sm mt-2">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Doloribus recusandae, assumenda deleniti totam aliquid suscipit iusto, tenetur facere excepturi nam ad distinctio? Harum cupiditate, eveniet facilis corporis ea dolorum. Nihil?
                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nesciunt officiis tenetur vel voluptate a enim delectus dicta! Rerum, dolorem consequatur perspiciatis eaque, dolorum illum aspernatur, veritatis in officia nemo earum?
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Temporibus quam, eos illo quos sint dolores quibusdam ipsum, nemo amet veritatis ipsa perspiciatis suscipit expedita? Vitae repellendus officia distinctio architecto obcaecati.
               </p>
            </div>
          </div>
          <div class="w-1/2 space-y-4">
            <div class="widget">
              <div class="flex space-x-2 mb-4">
                <button
                  id="aboutMeTab"
                  class="tab-active px-4 py-2 rounded"
                  onClick={about}
                >
                  About Me
                </button>
                <button
                  id="experiencesTab"
                  class=" px-4 py-2 rounded"
                  onClick={experienc}
                >
                  Experiences
                </button>
                <button
                  id="recommendedTab"
                  class=" px-4 py-2 rounded"
                  onClick={recommended}
                >
                  Recommended
                </button>
              </div>
              <div id="aboutMe" class="text-sm overflow-y-auto h-28">
                <p>
                  Hello! I'm DHEERAJ KUMAR, I have completed my 3 internships and now currently i am pursuing my b-tech 
                  . I've completed my 2 years now i am a 3rd year student.
                  been working at this awesome company for 3 years now.
                </p>
                <p>
                  I was born and raised in Albany, NY & have been living in
                  Santa Carla for the past 10 years my wife Tiffany and my 4
                  year old twin daughters - Emma and Ella. Both of them are just
                  starting school, so my calendar is usually blocked between
                  9-10 AM. This is a...
                  Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempora est ea non at cupiditate a ullam minus, fugiat labore, corrupti dolore accusantium? Ipsa cumque iure minima culpa, similique vel explicabo.
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Provident quis, laborum facilis amet rem ab nisi eos facere odio illo non quod recusandae fugit minus animi inventore voluptates ut hic.
                </p>
              </div>
              <div id="experiences" class="text-sm hidden overflow-y-auto h-28">
                <p>Experience content goes here...
                  Lorem ipsum dolor, sit amet consectetur adipisicing elit. A perspiciatis aliquam laboriosam nihil eveniet incidunt itaque nulla voluptas saepe repudiandae? Enim nam omnis distinctio suscipit eveniet ad quia quam doloribus!
                  Lorem ipsum dolor sit, amet consectetur adipisicing elit. Unde quae laboriosam, corrupti, animi esse corporis voluptate doloremque asperiores ex consequuntur reprehenderit possimus quas impedit maiores ipsam expedita! Eum, laborum doloribus?
                  Lorem ipsum dolor, sit amet consectetur adipisicing elit. Adipisci eius possimus ducimus rerum ea nostrum libero, fugit est iste amet placeat temporibus ad velit delectus officia harum corporis saepe recusandae?
                </p>
              </div>
              <div id="recommended" class="text-sm hidden overflow-y-auto h-28">
                <p>Recommended content goes here...</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus accusantium repellat earum ea assumenda esse distinctio? Reiciendis possimus, provident quis ea mollitia, sed quisquam autem quod nisi, sit incidunt fugit?</p>
              </div>
            </div>
            <div class="widget">
              <div class="flex justify-between items-center mb-4">
                <h2 class="text-lg">Gallery</h2>
                <div class="flex items-center space-x-2" >
                  <button
                    class="bg-gray-700 text-white px-4 py-2 rounded flex items-center space-x-2"
                     onClick={addImage}
                  >
                    <i class="fas fa-plus"></i>
                    <span>ADD IMAGE</span>
                  </button>
                  <button
                    class="bg-gray-700 text-white px-4 py-2 rounded"
                    onClick={prevImage}
                  >
                    <i class="fas fa-arrow-left"></i>
                  </button>
                  <button
                    class="bg-gray-700 text-white px-4 py-2 rounded"
                    onClick={nextImage}
                  >
                    <i class="fas fa-arrow-right"></i>
                  </button>
                </div>
              </div>
              <div id="gallery" class="flex space-x-2 overflow-hidden">
                <div class="gallery-image active"></div>
                <div class="gallery-image"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default App;
